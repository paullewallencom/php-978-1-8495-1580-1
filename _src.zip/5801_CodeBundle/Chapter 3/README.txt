PACKT - Netbeans PHP Application Development

Chapter 3 : Building a Facebook-like Status Poster using NetBeans
-----------------------

1. Create a database named status_poster
2. Import the status_poster.sql file into that database
3. At StatusPoster.php : adjust class constants for database access credentials
4. Copy the project folder inside your web root i.e. htdocs, www etc.
5. May adjust the BASE_URL at index.php as per your project directory name 
6. Test from browser i.e. http://localhost/chapter3