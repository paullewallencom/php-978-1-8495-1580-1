PACKT - Netbeans PHP Application Development

Chapter 7 : Building User Registration, Login & Logout
-----------------------

1. create a database named 'user'
2. import the users.sql file into that database
3. at UserDao.php : adjust database access credentials
4. copy the project folder inside your web root i.e. htdocs, www etc.
5. test from browser: http://localhost/chapter7