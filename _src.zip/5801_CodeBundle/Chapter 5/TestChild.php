<?php

/**
 * Short description of the TestChild Class
 *
 * Long multiline description of the TestChild Class goes here
 *
 * Note: any notes required 
 * @package Chapter5
 * @author M A Hossain Tonu
 * @version 1.0
 * @copyright never
 * @link http://mahtonu.wordpress.com
 */
class TestChild extends Test {
    
    //TODO have to add class variable and functions 
}

?>
