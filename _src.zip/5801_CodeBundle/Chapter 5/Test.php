<?php

/**
 * Short description of the Test Class
 *
 * Long multiline description of the Test Class goes here
 *
 * Note: any notes required 
 * @package Chapter5
 * @author M A Hossain Tonu
 * @version 1.0
 * @copyright never
 * @link http://mahtonu.wordpress.com
 */
class Test {
    /**
     * example of documenting a variable's type
     * @var string 
     */
    public $variable;
    
}

?>
