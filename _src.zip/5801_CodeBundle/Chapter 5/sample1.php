<?php

/**
 * a short description goes here
 * 
 * @param DateTime $param1 this is parameter1
 * @param array $param2 this is parameter2
 * @param string $param3 this is parameter3 which is optional
 * @return int what is returned, goes here
 */
function testFunc(DateTime $param1, $param2, string $param3 = NULL)
{
    $number = 7;

    return $number;
}
?>
